/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package envanterotomasyon;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Java3
 */
@Entity
@Table(name = "teklifler")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Teklifler.findAll", query = "SELECT t FROM Teklifler t"),
    @NamedQuery(name = "Teklifler.findByTeklifId", query = "SELECT t FROM Teklifler t WHERE t.teklifId = :teklifId"),
    @NamedQuery(name = "Teklifler.findByTeklifAdi", query = "SELECT t FROM Teklifler t WHERE t.teklifAdi = :teklifAdi"),
    @NamedQuery(name = "Teklifler.findByTeklifTekliflistesiId", query = "SELECT t FROM Teklifler t WHERE t.teklifTekliflistesiId = :teklifTekliflistesiId"),
    @NamedQuery(name = "Teklifler.findByTeklifFirmaId", query = "SELECT t FROM Teklifler t WHERE t.teklifFirmaId = :teklifFirmaId"),
    @NamedQuery(name = "Teklifler.findByTeklifAciklama", query = "SELECT t FROM Teklifler t WHERE t.teklifAciklama = :teklifAciklama"),
    @NamedQuery(name = "Teklifler.findByTeklifUrunAdedi", query = "SELECT t FROM Teklifler t WHERE t.teklifUrunAdedi = :teklifUrunAdedi"),
    @NamedQuery(name = "Teklifler.findByTeklifFiyati", query = "SELECT t FROM Teklifler t WHERE t.teklifFiyati = :teklifFiyati"),
    @NamedQuery(name = "Teklifler.findByTeklifOnayDurumu", query = "SELECT t FROM Teklifler t WHERE t.teklifOnayDurumu = :teklifOnayDurumu"),
    @NamedQuery(name = "Teklifler.findByTeklifTuru", query = "SELECT t FROM Teklifler t WHERE t.teklifTuru = :teklifTuru"),
    @NamedQuery(name = "Teklifler.findByTeklifTarih", query = "SELECT t FROM Teklifler t WHERE t.teklifTarih = :teklifTarih")})
public class Teklifler implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "teklif_id")
    private Integer teklifId;
    @Column(name = "teklif_adi")
    private String teklifAdi;
    @Column(name = "teklif_tekliflistesi_id")
    private Integer teklifTekliflistesiId;
    @Column(name = "teklif_firma_id")
    private Integer teklifFirmaId;
    @Column(name = "teklif_aciklama")
    private String teklifAciklama;
    @Column(name = "teklif_urun_adedi")
    private Integer teklifUrunAdedi;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "teklif_fiyati")
    private Double teklifFiyati;
    @Column(name = "teklif_onay_durumu")
    private String teklifOnayDurumu;
    @Column(name = "teklif_turu")
    private String teklifTuru;
    @Column(name = "teklif_tarih")
    @Temporal(TemporalType.TIMESTAMP)
    private Date teklifTarih;

    public Teklifler() {
    }

    public Teklifler(Integer teklifId) {
        this.teklifId = teklifId;
    }

    public Integer getTeklifId() {
        return teklifId;
    }

    public void setTeklifId(Integer teklifId) {
        this.teklifId = teklifId;
    }

    public String getTeklifAdi() {
        return teklifAdi;
    }

    public void setTeklifAdi(String teklifAdi) {
        this.teklifAdi = teklifAdi;
    }

    public Integer getTeklifTekliflistesiId() {
        return teklifTekliflistesiId;
    }

    public void setTeklifTekliflistesiId(Integer teklifTekliflistesiId) {
        this.teklifTekliflistesiId = teklifTekliflistesiId;
    }

    public Integer getTeklifFirmaId() {
        return teklifFirmaId;
    }

    public void setTeklifFirmaId(Integer teklifFirmaId) {
        this.teklifFirmaId = teklifFirmaId;
    }

    public String getTeklifAciklama() {
        return teklifAciklama;
    }

    public void setTeklifAciklama(String teklifAciklama) {
        this.teklifAciklama = teklifAciklama;
    }

    public Integer getTeklifUrunAdedi() {
        return teklifUrunAdedi;
    }

    public void setTeklifUrunAdedi(Integer teklifUrunAdedi) {
        this.teklifUrunAdedi = teklifUrunAdedi;
    }

    public Double getTeklifFiyati() {
        return teklifFiyati;
    }

    public void setTeklifFiyati(Double teklifFiyati) {
        this.teklifFiyati = teklifFiyati;
    }

    public String getTeklifOnayDurumu() {
        return teklifOnayDurumu;
    }

    public void setTeklifOnayDurumu(String teklifOnayDurumu) {
        this.teklifOnayDurumu = teklifOnayDurumu;
    }

    public String getTeklifTuru() {
        return teklifTuru;
    }

    public void setTeklifTuru(String teklifTuru) {
        this.teklifTuru = teklifTuru;
    }

    public Date getTeklifTarih() {
        return teklifTarih;
    }

    public void setTeklifTarih(Date teklifTarih) {
        this.teklifTarih = teklifTarih;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (teklifId != null ? teklifId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Teklifler)) {
            return false;
        }
        Teklifler other = (Teklifler) object;
        if ((this.teklifId == null && other.teklifId != null) || (this.teklifId != null && !this.teklifId.equals(other.teklifId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "envanterotomasyon.Teklifler[ teklifId=" + teklifId + " ]";
    }
    
}
